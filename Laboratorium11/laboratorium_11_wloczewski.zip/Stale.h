#pragma once
#define COLOR_CZERWONY	"\x1b[31m"
#define COLOR_ZIELONY   "\x1b[32m"
#define COLOR_ZOLTY		"\x1b[33m"
#define COLOR_MAGENTA	"\x1b[35m"
#define COLOR_CYAN		"\x1b[36m"
#define COLOR_RESET		"\x1b[0m"
#define COLOR_NIEBIESKI	"\x1b[34m"